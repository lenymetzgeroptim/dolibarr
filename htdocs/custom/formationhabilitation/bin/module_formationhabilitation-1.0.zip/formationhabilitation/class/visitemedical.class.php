<?php
/* Copyright (C) 2017  Laurent Destailleur      <eldy@users.sourceforge.net>
 * Copyright (C) 2023  Frédéric France          <frederic.france@netlogic.fr>
 * Copyright (C) 2024 METZGER Leny <l.metzger@optim-industries.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file        class/visitemedical.class.php
 * \ingroup     formationhabilitation
 * \brief       This file is a CRUD class file for VisiteMedical (Create/Read/Update/Delete)
 */

// Put here all includes required by your class file
require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/custom/formationhabilitation/class/userformation.class.php';
require_once DOL_DOCUMENT_ROOT.'/custom/formationhabilitation/class/formation.class.php';
require_once DOL_DOCUMENT_ROOT.'/custom/formationhabilitation/class/userhabilitation.class.php';
require_once DOL_DOCUMENT_ROOT.'/custom/formationhabilitation/class/habilitation.class.php';
require_once DOL_DOCUMENT_ROOT.'/custom/formationhabilitation/class/userautorisation.class.php';
require_once DOL_DOCUMENT_ROOT.'/custom/formationhabilitation/class/autorisation.class.php';
require_once DOL_DOCUMENT_ROOT.'/custom/formationhabilitation/lib/formationhabilitation.lib.php';

/**
 * Class for VisiteMedical
 */
class VisiteMedical extends CommonObject
{
	/**
	 * @var string ID of module.
	 */
	public $module = 'formationhabilitation';

	/**
	 * @var string ID to identify managed object.
	 */
	public $element = 'visitemedical';

	/**
	 * @var string Name of table without prefix where object is stored. This is also the key used for extrafields management.
	 */
	public $table_element = 'formationhabilitation_visitemedical';

	/**
	 * @var int  	Does this object support multicompany module ?
	 * 0=No test on entity, 1=Test with field entity, 'field@table'=Test with link by field@table
	 */
	public $ismultientitymanaged = 0;

	/**
	 * @var int  Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 0;

	/**
	 * @var string String with name of icon for visitemedical. Must be a 'fa-xxx' fontawesome code (or 'fa-xxx_fa_color_size') or 'visitemedical@formationhabilitation' if picto is file 'img/object_visitemedical.png'.
	 */
	public $picto = 'fa-hospital-alt_fas_#b4161b';


	const STATUS_APTE = 1;
	const STATUS_CONDITIONNEL = 2;
	const STATUS_INAPTE = 3;
	const STATUS_EXPIRE = 8;
	const STATUS_CLOSE = 9;

	/**
	 *  'type' field format:
	 *  	'integer', 'integer:ObjectClass:PathToClass[:AddCreateButtonOrNot[:Filter[:Sortfield]]]',
	 *  	'select' (list of values are in 'options'),
	 *  	'sellist:TableName:LabelFieldName[:KeyFieldName[:KeyFieldParent[:Filter[:CategoryIdType[:CategoryIdList[:SortField]]]]]]',
	 *  	'chkbxlst:...',
	 *  	'varchar(x)',
	 *  	'text', 'text:none', 'html',
	 *   	'double(24,8)', 'real', 'price', 'stock',
	 *  	'date', 'datetime', 'timestamp', 'duration',
	 *  	'boolean', 'checkbox', 'radio', 'array',
	 *  	'mail', 'phone', 'url', 'password', 'ip'
	 *		Note: Filter must be a Dolibarr Universal Filter syntax string. Example: "(t.ref:like:'SO-%') or (t.date_creation:<:'20160101') or (t.status:!=:0) or (t.nature:is:NULL)"
	 *  'label' the translation key.
	 *  'picto' is code of a picto to show before value in forms
	 *  'enabled' is a condition when the field must be managed (Example: 1 or 'getDolGlobalInt("MY_SETUP_PARAM")' or 'isModEnabled("multicurrency")' ...)
	 *  'position' is the sort order of field.
	 *  'notnull' is set to 1 if not null in database. Set to -1 if we must set data to null if empty ('' or 0).
	 *  'visible' says if field is visible in list (Examples: 0=Not visible, 1=Visible on list and create/update/view forms, 2=Visible on list only, 3=Visible on create/update/view form only (not list), 4=Visible on list and update/view form only (not create). 5=Visible on list and view only (not create/not update). Using a negative value means field is not shown by default on list but can be selected for viewing)
	 *  'noteditable' says if field is not editable (1 or 0)
	 *  'alwayseditable' says if field can be modified also when status is not draft ('1' or '0')
	 *  'default' is a default value for creation (can still be overwrote by the Setup of Default Values if field is editable in creation form). Note: If default is set to '(PROV)' and field is 'ref', the default value will be set to '(PROVid)' where id is rowid when a new record is created.
	 *  'index' if we want an index in database.
	 *  'foreignkey'=>'tablename.field' if the field is a foreign key (it is recommanded to name the field fk_...).
	 *  'searchall' is 1 if we want to search in this field when making a search from the quick search button.
	 *  'isameasure' must be set to 1 or 2 if field can be used for measure. Field type must be summable like integer or double(24,8). Use 1 in most cases, or 2 if you don't want to see the column total into list (for example for percentage)
	 *  'css' and 'cssview' and 'csslist' is the CSS style to use on field. 'css' is used in creation and update. 'cssview' is used in view mode. 'csslist' is used for columns in lists. For example: 'css'=>'minwidth300 maxwidth500 widthcentpercentminusx', 'cssview'=>'wordbreak', 'csslist'=>'tdoverflowmax200'
	 *  'help' and 'helplist' is a 'TranslationString' to use to show a tooltip on field. You can also use 'TranslationString:keyfortooltiponlick' for a tooltip on click.
	 *  'showoncombobox' if value of the field must be visible into the label of the combobox that list record
	 *  'disabled' is 1 if we want to have the field locked by a 'disabled' attribute. In most cases, this is never set into the definition of $fields into class, but is set dynamically by some part of code.
	 *  'arrayofkeyval' to set a list of values if type is a list of predefined values. For example: array("0"=>"Draft","1"=>"Active","-1"=>"Cancel"). Note that type can be 'integer' or 'varchar'
	 *  'autofocusoncreate' to have field having the focus on a create form. Only 1 field should have this property set to 1.
	 *  'comment' is not used. You can store here any text of your choice. It is not used by application.
	 *	'validate' is 1 if need to validate with $this->validateField()
	 *  'copytoclipboard' is 1 or 2 to allow to add a picto to copy value into clipboard (1=picto after label, 2=picto after value)
	 *
	 *  Note: To have value dynamic, you can set value to 0 in definition and edit the value on the fly into the constructor.
	 */

	// BEGIN MODULEBUILDER PROPERTIES
	/**
	 * @var array  Array with all fields and their property. Do not use it as a static var. It may be modified by constructor.
	 */
	public $fields=array(
		"rowid" => array("type"=>"integer", "label"=>"TechnicalID", "enabled"=>"1", 'position'=>1, 'notnull'=>1, "visible"=>"0", "noteditable"=>"1", "index"=>"1", "css"=>"left", "comment"=>"Id"),
		"ref" => array("type"=>"varchar(128)", "label"=>"Ref", "enabled"=>"1", 'position'=>20, 'notnull'=>1, "visible"=>"1", "index"=>"1", "searchall"=>"1", "showoncombobox"=>"1", "validate"=>"1", "comment"=>"Reference of object"),
		"note_public" => array("type"=>"html", "label"=>"NotePublic", "enabled"=>"1", 'position'=>61, 'notnull'=>0, "visible"=>"0", "cssview"=>"wordbreak", "validate"=>"1",),
		"note_private" => array("type"=>"html", "label"=>"NotePrivate", "enabled"=>"1", 'position'=>62, 'notnull'=>0, "visible"=>"0", "cssview"=>"wordbreak", "validate"=>"1",),
		"date_creation" => array("type"=>"datetime", "label"=>"DateCreation", "enabled"=>"1", 'position'=>500, 'notnull'=>1, "visible"=>"-2",),
		"tms" => array("type"=>"timestamp", "label"=>"DateModification", "enabled"=>"1", 'position'=>501, 'notnull'=>0, "visible"=>"-2",),
		"fk_user_creat" => array("type"=>"integer:User:user/class/user.class.php", "label"=>"UserAuthor", "picto"=>"user", "enabled"=>"1", 'position'=>510, 'notnull'=>1, "visible"=>"-2", "csslist"=>"tdoverflowmax150",),
		"fk_user_modif" => array("type"=>"integer:User:user/class/user.class.php", "label"=>"UserModif", "picto"=>"user", "enabled"=>"1", 'position'=>511, 'notnull'=>-1, "visible"=>"-2", "csslist"=>"tdoverflowmax150",),
		"last_main_doc" => array("type"=>"varchar(255)", "label"=>"LastMainDoc", "enabled"=>"1", 'position'=>600, 'notnull'=>0, "visible"=>"0",),
		"import_key" => array("type"=>"varchar(14)", "label"=>"ImportId", "enabled"=>"1", 'position'=>1000, 'notnull'=>-1, "visible"=>"-2",),
		"model_pdf" => array("type"=>"varchar(255)", "label"=>"Model pdf", "enabled"=>"1", 'position'=>1010, 'notnull'=>-1, "visible"=>"0",),
		"status" => array("type"=>"integer", "label"=>"Resultat", "enabled"=>"1", 'position'=>2000, 'notnull'=>1, "visible"=>"1", "index"=>"1", "arrayofkeyval"=>array("1" => "Apte", "3" => "Inapte", "2" => "Conditionnelle", "8" => "Expirée", "9" => "Clôturée"), "validate"=>"1",),
		"commentaire" => array("type"=>"html", "label"=>"Commentaire", "enabled"=>"1", 'position'=>50, 'notnull'=>0, "visible"=>"1",),
		"fk_contact" => array("type"=>"integer:contact:contact/class/contact.class.php:0:(civility:=:'dr')", "label"=>"Medecin", "enabled"=>"1", 'position'=>36, 'notnull'=>1, "visible"=>"1",),
		"objetvisite" => array("type"=>"varchar(128)", "label"=>"ObjetVisite", "enabled"=>"1", 'position'=>25, 'notnull'=>0, "visible"=>"1",),
		"motifvisite" => array("type"=>"sellist:c_motif_visite:label:rowid::(active:=:1)", "label"=>"MotifVisite", "enabled"=>"1", 'position'=>26, 'notnull'=>1, "visible"=>"1",),
		"demandeurvisite" => array("type"=>"integer", "label"=>"DemandeurVisite", "enabled"=>"1", 'position'=>27, 'notnull'=>1, "visible"=>"1", "arrayofkeyval"=>array("0" => "Employeur", "1" => "Médecin", "2" => "Salarié", "3" => "Autre"),),
		"datevisite" => array("type"=>"date", "label"=>"DateVisite", "enabled"=>"1", 'position'=>30, 'notnull'=>1, "visible"=>"1",),
		"datefinvalidite" => array("type"=>"date", "label"=>"DateFinValidite", "enabled"=>"1", 'position'=>31, 'notnull'=>1, "visible"=>"1",),
		"coutvisite" => array("type"=>"price", "label"=>"CoutVisite", "enabled"=>"1", 'position'=>35, 'notnull'=>0, "visible"=>"1",),
		"naturevisite" => array("type"=>"chkbxlst:c_nature_visite:label:rowid::(active=1)", "label"=>"NatureVisite", "enabled"=>"1", 'position'=>37, 'notnull'=>1, "visible"=>"1",),
		"fk_user" => array("type"=>"integer:user:user/class/user.class.php:0:(statut:=:1)", "label"=>"Utilisateur", "enabled"=>"1", 'position'=>21, 'notnull'=>1, "visible"=>"1",),
	);
	public $rowid;
	public $ref;
	public $note_public;
	public $note_private;
	public $date_creation;
	public $tms;
	public $fk_user_creat;
	public $fk_user_modif;
	public $last_main_doc;
	public $import_key;
	public $model_pdf;
	public $status;
	public $commentaire;
	public $fk_contact;
	public $objetvisite;
	public $motifvisite;
	public $demandeurvisite;
	public $datevisite;
	public $datefinvalidite;
	public $coutvisite;
	public $naturevisite;
	public $fk_user;
	// END MODULEBUILDER PROPERTIES


	// If this object has a subtable with lines

	// /**
	//  * @var string    Name of subtable line
	//  */
	// public $table_element_line = 'formationhabilitation_visitemedicalline';

	// /**
	//  * @var string    Field with ID of parent key if this object has a parent
	//  */
	// public $fk_element = 'fk_visitemedical';

	// /**
	//  * @var string    Name of subtable class that manage subtable lines
	//  */
	// public $class_element_line = 'VisiteMedicalline';

	// /**
	//  * @var array	List of child tables. To test if we can delete object.
	//  */
	// protected $childtables = array('mychildtable' => array('name'=>'VisiteMedical', 'fk_element'=>'fk_visitemedical'));

	// /**
	//  * @var array    List of child tables. To know object to delete on cascade.
	//  *               If name matches '@ClassNAme:FilePathClass;ParentFkFieldName' it will
	//  *               call method deleteByParentField(parentId, ParentFkFieldName) to fetch and delete child object
	//  */
	// protected $childtablesoncascade = array('formationhabilitation_visitemedicaldet');

	// /**
	//  * @var VisiteMedicalLine[]     Array of subtable lines
	//  */
	// public $lines = array();



	/**
	 * Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
		global $conf, $langs;

		$this->db = $db;

		if (!getDolGlobalInt('MAIN_SHOW_TECHNICAL_ID') && isset($this->fields['rowid']) && !empty($this->fields['ref'])) {
			$this->fields['rowid']['visible'] = 0;
		}
		if (!isModEnabled('multicompany') && isset($this->fields['entity'])) {
			$this->fields['entity']['enabled'] = 0;
		}

		// Example to show how to set values of fields definition dynamically
		/*if ($user->hasRight('formationhabilitation', 'visitemedical', 'read')) {
			$this->fields['myfield']['visible'] = 1;
			$this->fields['myfield']['noteditable'] = 0;
		}*/

		// Unset fields that are disabled
		foreach ($this->fields as $key => $val) {
			if (isset($val['enabled']) && empty($val['enabled'])) {
				unset($this->fields[$key]);
			}
		}

		// Translate some data of arrayofkeyval
		if (is_object($langs)) {
			foreach ($this->fields as $key => $val) {
				if (!empty($val['arrayofkeyval']) && is_array($val['arrayofkeyval'])) {
					foreach ($val['arrayofkeyval'] as $key2 => $val2) {
						$this->fields[$key]['arrayofkeyval'][$key2] = $langs->trans($val2);
					}
				}
			}
		}
	}

	/**
	 * Create object into database
	 *
	 * @param  User $user      User that creates
	 * @param  bool $notrigger false=launch triggers after, true=disable triggers
	 * @return int             Return integer <0 if KO, Id of created object if OK
	 */
	public function create(User $user, $notrigger = false)
	{
		global $conf, $langs; 

		$this->actionmsg = msgAgendaUpdate($this, 0);
		$resultcreate = $this->createCommon($user, $notrigger);

		if($resultcreate) {
			$visitemedicaleToClose = $this->getVisiteMedicaleToClose();

			if($visitemedicaleToClose < 0) {
				return -1;
			}

			foreach($visitemedicaleToClose as $visitemedicale) {
				$resultclose = $visitemedicale->close($user);

				if($resultclose < 0) {
					return -1;
				}
			}
		}

		// Si VM apte => Unsuspend les lignes
		if($resultcreate && ($this->status == self::STATUS_APTE || $this->status == self::STATUS_CONDITIONNEL)) {
			$naturesVisite = explode(",", $this->naturevisite);
			$elementPrerequis = new ElementPrerequis($this->db);

			// Formations
			$userFormation = new UserFormation($this->db);
			$formation = new Formation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userFormationToUnsuspend = $userFormation->getSuspendObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userFormationToUnsuspend as $user_formation) {
					$formation->fetch($user_formation->fk_formation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $formation, 0, 0);
					if($asPrerequis > 0) {
						$resultsuspen = $user_formation->unsuspend($user);

						if($resultsuspen < 0) {
							return -1;
						}
					}
				}
			}
			
			// Habilitations
			$userHabilitation = new UserHabilitation($this->db);
			$habilitation = new Habilitation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userHabilitationToUnsuspend = $userHabilitation->getSuspendObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userHabilitationToUnsuspend as $user_habilitation) {
					$habilitation->fetch($user_habilitation->fk_habilitation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $habilitation, 0, 0);
					if($asPrerequis > 0) {
						$resultsuspen = $user_habilitation->unsuspend($user);

						if($resultsuspen < 0) {
							return -1;
						}
					}
				}
			}

			// Autorisations
			$userAutorisation = new UserAutorisation($this->db);
			$autorisation = new Autorisation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userAutorisationToUnsuspend = $userAutorisation->getSuspendObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userAutorisationToUnsuspend as $user_autorisation) {
					$autorisation->fetch($user_autorisation->fk_autorisation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $autorisation, 0, 0);
					if($asPrerequis > 0) {
						$resultsuspen = $user_autorisation->unsuspend($user);

						if($resultsuspen < 0) {
							return -1;
						}
					}
				}
			}
		}
		elseif ($resultcreate && $this->status == self::STATUS_INAPTE) {
			$naturesVisite = explode(",", $this->naturevisite);
			$elementPrerequis = new ElementPrerequis($this->db);

			// Formations
			$userFormation = new UserFormation($this->db);
			$formation = new Formation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userFormationToSuspend = $userFormation->getObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userFormationToSuspend as $user_formation) {
					$formation->fetch($user_formation->fk_formation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $formation, 0, 0);
					if($asPrerequis < 0) {
						$resultsuspen = $user_formation->suspend($user);

						if($resultsuspen < 0) {
							$error++;
						}
					}
				}
			}
			
			// Habilitations
			$userHabilitation = new UserHabilitation($this->db);
			$habilitation = new Habilitation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userHabilitationToSuspend = $userHabilitation->getObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userHabilitationToSuspend as $user_habilitation) {
					$habilitation->fetch($user_habilitation->fk_habilitation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $habilitation, 0, 0);
					if($asPrerequis < 0) {
						$resultsuspen = $user_habilitation->suspend($user);

						if($resultsuspen < 0) {
							$error++;
						}
					}
				}
			}

			// Autorisations
			$userAutorisation = new UserAutorisation($this->db);
			$autorisation = new Autorisation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userAutorisationToSuspend = $userAutorisation->getObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userAutorisationToSuspend as $user_autorisation) {
					$autorisation->fetch($user_autorisation->fk_autorisation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $autorisation, 0, 0);
					if($asPrerequis < 0) {
						$resultsuspen = $user_autorisation->suspend($user);

						if($resultsuspen < 0) {
							$error++;
						}
					}
				}
			}
		}

		// Envoi d'un mail au responsable Q3SE et responsable d’antenne si VM conditionnel
		if($resultcreate && $this->status == self::STATUS_CONDITIONNEL) {
			global $dolibarr_main_url_root;
	
			$user_group = New UserGroup($this->db);
			$user_group->fetch(0, "Responsable d'antenne");
			$arrayUserRespAntenneGroup = $user_group->listUsersForGroup('', 1);
			$societe = New Societe($this->db);
			$user_static = new User($this->db);
			$user_static->fetch($this->fk_user);
			$societe->fetch($user_static->array_options['options_antenne']);
			$arrayUserRespAntenne = $societe->getSalesRepresentatives($user, 1);
			$arrayRespAntenneForMail = array_intersect($arrayUserRespAntenneGroup, $arrayUserRespAntenne);
			$user_group->fetch(0, 'Resp. Q3SE');
			$liste_q3se = $user_group->listUsersForGroup('u.statut=1');

			$subject = "[OPTIM Industries] Notification automatique ".$langs->transnoentitiesnoconv($this->module);
			$from = $conf->global->MAIN_MAIL_EMAIL_FROM;

			$to = '';
			foreach($arrayRespAntenneForMail as $user_id) {
				$user_static->fetch($user_id);

				if(!empty($user_static->email)) {
					$to .= $user_static->email.', ';
				}
			}

			foreach($liste_q3se as $q3se){
				if(!empty($q3se->email)){
					$to .= $q3se->email.", ";
				}
			}
			rtrim($to, ', ');
			
			$urlwithouturlroot = preg_replace('/'.preg_quote(DOL_URL_ROOT, '/').'$/i', '', trim($dolibarr_main_url_root));
			$urlwithroot = $urlwithouturlroot.DOL_URL_ROOT; // This is to use external domain name found into config file

			$user_static->fetch($this->fk_user);
			$link = '<a href="'.$urlwithroot.'/custom/formationhabilitation/visitemedical_card.php?id='.$this->id.'">ici</a>';
			$message = $langs->transnoentitiesnoconv("EMailTextVisiteMedicaleConditionnel", $user_static->firstname, $user_static->lastname, $link);

			$mail = new CMailFile(
				$subject,
				$to,
				$from,
				$message,
				array(),
				array(),
				array(),
				'',
				'',
				0,
				1,
				'',
				''
			);

			if(!empty($to)) {
				//$resultmail = $mail->sendfile();

				if (!$resultmail) {
					//setEventMessages($mail->error, $mail->errors, 'warnings'); // Show error, but do no make rollback, so $error is not set to 1
				}
			}
		}

		return $resultcreate;
	}

	/**
	 * Clone an object into another one
	 *
	 * @param  	User 	$user      	User that creates
	 * @param  	int 	$fromid     Id of object to clone
	 * @return 	mixed 				New object created, <0 if KO
	 */
	public function createFromClone(User $user, $fromid)
	{
		global $langs, $extrafields;
		$error = 0;

		dol_syslog(__METHOD__, LOG_DEBUG);

		$object = new self($this->db);

		$this->db->begin();

		// Load source object
		$result = $object->fetchCommon($fromid);
		if ($result > 0 && !empty($object->table_element_line)) {
			$object->fetchLines();
		}

		// get lines so they will be clone
		//foreach($this->lines as $line)
		//	$line->fetch_optionals();

		// Reset some properties
		unset($object->id);
		unset($object->fk_user_creat);
		unset($object->import_key);

		// Clear fields
		if (property_exists($object, 'ref')) {
			$object->ref = empty($this->fields['ref']['default']) ? "Copy_Of_".$object->ref : $this->fields['ref']['default'];
		}
		if (property_exists($object, 'label')) {
			$object->label = empty($this->fields['label']['default']) ? $langs->trans("CopyOf")." ".$object->label : $this->fields['label']['default'];
		}
		if (property_exists($object, 'date_creation')) {
			$object->date_creation = dol_now();
		}
		if (property_exists($object, 'date_modification')) {
			$object->date_modification = null;
		}
		// ...
		// Clear extrafields that are unique
		if (is_array($object->array_options) && count($object->array_options) > 0) {
			$extrafields->fetch_name_optionals_label($this->table_element);
			foreach ($object->array_options as $key => $option) {
				$shortkey = preg_replace('/options_/', '', $key);
				if (!empty($extrafields->attributes[$this->table_element]['unique'][$shortkey])) {
					//var_dump($key);
					//var_dump($clonedObj->array_options[$key]); exit;
					unset($object->array_options[$key]);
				}
			}
		}

		// Create clone
		$object->context['createfromclone'] = 'createfromclone';
		$result = $object->createCommon($user);
		if ($result < 0) {
			$error++;
			$this->setErrorsFromObject($object);
		}

		if (!$error) {
			// copy internal contacts
			if ($this->copy_linked_contact($object, 'internal') < 0) {
				$error++;
			}
		}

		if (!$error) {
			// copy external contacts if same company
			if (!empty($object->socid) && property_exists($this, 'fk_soc') && $this->fk_soc == $object->socid) {
				if ($this->copy_linked_contact($object, 'external') < 0) {
					$error++;
				}
			}
		}

		unset($object->context['createfromclone']);

		// End
		if (!$error) {
			$this->db->commit();
			return $object;
		} else {
			$this->db->rollback();
			return -1;
		}
	}

	/**
	 * Load object in memory from the database
	 *
	 * @param 	int    	$id   			Id object
	 * @param 	string 	$ref  			Ref
	 * @param	int		$noextrafields	0=Default to load extrafields, 1=No extrafields
	 * @param	int		$nolines		0=Default to load extrafields, 1=No extrafields
	 * @return 	int     				Return integer <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetch($id, $ref = null, $noextrafields = 0, $nolines = 0)
	{
		$result = $this->fetchCommon($id, $ref, '', $noextrafields);
		if ($result > 0 && !empty($this->table_element_line) && empty($nolines)) {
			$this->fetchLines($noextrafields);
		}
		return $result;
	}

	/**
	 * Load object lines in memory from the database
	 *
	 * @param	int		$noextrafields	0=Default to load extrafields, 1=No extrafields
	 * @return 	int         			Return integer <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchLines($noextrafields = 0)
	{
		$this->lines = array();

		$result = $this->fetchLinesCommon('', $noextrafields);
		return $result;
	}


	/**
	 * Load list of objects in memory from the database. Using a fetchAll is a bad practice, instead try to forge you optimized and limited SQL request.
	 *
	 * @param  string      $sortorder    Sort Order
	 * @param  string      $sortfield    Sort field
	 * @param  int         $limit        limit
	 * @param  int         $offset       Offset
	 * @param  array       $filter       Filter array. Example array('mystringfield'=>'value', 'myintfield'=>4, 'customsql'=>...)
	 * @param  string      $filtermode   Filter mode (AND or OR)
	 * @return array|int                 int <0 if KO, array of pages if OK
	 */
	public function fetchAll($sortorder = '', $sortfield = '', $limit = 0, $offset = 0, array $filter = array(), $filtermode = 'AND')
	{
		dol_syslog(__METHOD__, LOG_DEBUG);

		$records = array();

		$sql = "SELECT ";
		$sql .= $this->getFieldList('t');
		$sql .= " FROM ".$this->db->prefix().$this->table_element." as t";
		if (isset($this->isextrafieldmanaged) && $this->isextrafieldmanaged == 1) {
			$sql .= " LEFT JOIN ".$this->db->prefix().$this->table_element."_extrafields as te ON te.fk_object = t.rowid";
		}
		if (isset($this->ismultientitymanaged) && $this->ismultientitymanaged == 1) {
			$sql .= " WHERE t.entity IN (".getEntity($this->element).")";
		} else {
			$sql .= " WHERE 1 = 1";
		}
		// Manage filter
		$sqlwhere = array();
		if (count($filter) > 0) {
			foreach ($filter as $key => $value) {
				$columnName = preg_replace('/^t\./', '', $key);
				if ($key === 'customsql') {
					// Never use 'customsql' with a value from user input since it is injected as is. The value must be hard coded.
					$sqlwhere[] = $value;
					continue;
				} elseif (isset($this->fields[$columnName])) {
					$type = $this->fields[$columnName]['type'];
					if (preg_match('/^integer/', $type)) {
						if (is_int($value)) {
							// single value
							$sqlwhere[] = $key . " = " . intval($value);
						} elseif (is_array($value)) {
							if (empty($value)) {
								continue;
							}
							$sqlwhere[] = $key . ' IN (' . $this->db->sanitize(implode(',', array_map('intval', $value))) . ')';
						}
						continue;
					} elseif (in_array($type, array('date', 'datetime', 'timestamp'))) {
						$sqlwhere[] = $key . " = '" . $this->db->idate($value) . "'";
						continue;
					}
				}

				// when the $key doesn't fall into the previously handled categories, we do as if the column were a varchar/text
				if (is_array($value) && count($value)) {
					$value = implode(',', array_map(function ($v) {
						return "'" . $this->db->sanitize($this->db->escape($v)) . "'";
					}, $value));
					$sqlwhere[] = $key . ' IN (' . $this->db->sanitize($value, true) . ')';
				} elseif (is_scalar($value)) {
					if (strpos($value, '%') === false) {
						$sqlwhere[] = $key . " = '" . $this->db->sanitize($this->db->escape($value)) . "'";
					} else {
						$sqlwhere[] = $key . " LIKE '%" . $this->db->escape($this->db->escapeforlike($value)) . "%'";
					}
				}
			}
		}
		if (count($sqlwhere) > 0) {
			$sql .= " AND (".implode(" ".$filtermode." ", $sqlwhere).")";
		}

		if (!empty($sortfield)) {
			$sql .= $this->db->order($sortfield, $sortorder);
		}
		if (!empty($limit)) {
			$sql .= $this->db->plimit($limit, $offset);
		}

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			$i = 0;
			while ($i < ($limit ? min($limit, $num) : $num)) {
				$obj = $this->db->fetch_object($resql);

				$record = new self($this->db);
				$record->setVarsFromFetchObj($obj);

				$records[$record->id] = $record;

				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}

	/**
	 * Update object into database
	 *
	 * @param  User $user      User that modifies
	 * @param  bool $notrigger false=launch triggers after, true=disable triggers
	 * @return int             Return integer <0 if KO, >0 if OK
	 */
	public function update(User $user, $notrigger = false)
	{
		$this->actionmsg = msgAgendaUpdate($this, 1);
		$resultupdate = $this->updateCommon($user, $notrigger);

		// Si VM apte => Unsuspend les lignes
		if($resultupdate && ($this->status == self::STATUS_APTE || $this->status == self::STATUS_CONDITIONNEL) && $this->oldcopy->status != self::STATUS_APTE && $this->oldcopy->status != self::STATUS_CONDITIONNEL) {
			$naturesVisite = explode(",", $this->naturevisite);
			$elementPrerequis = new ElementPrerequis($this->db);

			// Formations
			$userFormation = new UserFormation($this->db);
			$formation = new Formation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userFormationToUnsuspend = $userFormation->getSuspendObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userFormationToUnsuspend as $user_formation) {
					$formation->fetch($user_formation->fk_formation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $formation, 0, 0);
					if($asPrerequis > 0) {
						$resultsuspen = $user_formation->unsuspend($user);

						if($resultsuspen < 0) {
							return -1;
						}
					}
				}
			}
			
			// Habilitations
			$userHabilitation = new UserHabilitation($this->db);
			$habilitation = new Habilitation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userHabilitationToUnsuspend = $userHabilitation->getSuspendObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userHabilitationToUnsuspend as $user_habilitation) {
					$habilitation->fetch($user_habilitation->fk_habilitation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $habilitation, 0, 0);
					if($asPrerequis > 0) {
						$resultsuspen = $user_habilitation->unsuspend($user);

						if($resultsuspen < 0) {
							return -1;
						}
					}
				}
			}

			// Autorisations
			$userAutorisation = new UserAutorisation($this->db);
			$autorisation = new Autorisation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userAutorisationToUnsuspend = $userAutorisation->getSuspendObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userAutorisationToUnsuspend as $user_autorisation) {
					$autorisation->fetch($user_autorisation->fk_autorisation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $autorisation, 0, 0);
					if($asPrerequis > 0) {
						$resultsuspen = $user_autorisation->unsuspend($user);

						if($resultsuspen < 0) {
							return -1;
						}
					}
				}
			}
		}
		elseif ($resultupdate && $this->status == self::STATUS_INAPTE && $this->oldcopy->status != self::STATUS_INAPTE) {
			$naturesVisite = explode(",", $this->naturevisite);
			$elementPrerequis = new ElementPrerequis($this->db);

			// Formations
			$userFormation = new UserFormation($this->db);
			$formation = new Formation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userFormationToSuspend = $userFormation->getObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userFormationToSuspend as $user_formation) {
					$formation->fetch($user_formation->fk_formation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $formation, 0, 0);
					if($asPrerequis < 0) {
						$resultsuspen = $user_formation->suspend($user);

						if($resultsuspen < 0) {
							$error++;
						}
					}
				}
			}
			
			// Habilitations
			$userHabilitation = new UserHabilitation($this->db);
			$habilitation = new Habilitation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userHabilitationToSuspend = $userHabilitation->getObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userHabilitationToSuspend as $user_habilitation) {
					$habilitation->fetch($user_habilitation->fk_habilitation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $habilitation, 0, 0);
					if($asPrerequis < 0) {
						$resultsuspen = $user_habilitation->suspend($user);

						if($resultsuspen < 0) {
							$error++;
						}
					}
				}
			}

			// Autorisations
			$userAutorisation = new UserAutorisation($this->db);
			$autorisation = new Autorisation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userAutorisationToSuspend = $userAutorisation->getObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userAutorisationToSuspend as $user_autorisation) {
					$autorisation->fetch($user_autorisation->fk_autorisation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $autorisation, 0, 0);
					if($asPrerequis < 0) {
						$resultsuspen = $user_autorisation->suspend($user);

						if($resultsuspen < 0) {
							$error++;
						}
					}
				}
			}
		}

		return $resultupdate;
	}

	/**
	 * Delete object in database
	 *
	 * @param User $user       User that deletes
	 * @param bool $notrigger  false=launch triggers, true=disable triggers
	 * @return int             Return integer <0 if KO, >0 if OK
	 */
	public function delete(User $user, $notrigger = false)
	{
		$this->actionmsg = msgAgendaUpdate($this, 0);
		return $this->deleteCommon($user, $notrigger);
		//return $this->deleteCommon($user, $notrigger, 1);
	}

	/**
	 *  Delete a line of object in database
	 *
	 *	@param  User	$user       User that delete
	 *  @param	int		$idline		Id of line to delete
	 *  @param 	bool 	$notrigger  false=launch triggers after, true=disable triggers
	 *  @return int         		>0 if OK, <0 if KO
	 */
	public function deleteLine(User $user, $idline, $notrigger = false)
	{
		if ($this->status < 0) {
			$this->error = 'ErrorDeleteLineNotAllowedByObjectStatus';
			return -2;
		}

		return $this->deleteLineCommon($user, $idline, $notrigger);
	}


	/**
	 *	Expire object
	 *
	 *	@param		User	$user     		User making status change
	 *  @param		int		$notrigger		1=Does not execute triggers, 0= execute triggers
	 *	@return  	int						Return integer <=0 if OK, 0=Nothing done, >0 if KO
	 */
	public function expire($user, $notrigger = 0)
	{
		global $conf, $langs;

		require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

		$error = 0;

		// Protection
		if ($this->status == self::STATUS_EXPIRE) {
			dol_syslog(get_class($this)."::expire action abandonned: already expired", LOG_WARNING);
			return 0;
		}
		elseif ($this->status == self::STATUS_CLOSE) {
			dol_syslog(get_class($this)."::expire action abandonned: already closed", LOG_WARNING);
			return 0;
		}

		$now = dol_now();

		$this->db->begin();

		// Expire
		$sql = "UPDATE ".MAIN_DB_PREFIX.$this->table_element;
		$sql .= " SET status = ".self::STATUS_EXPIRE;
		$sql .= " WHERE rowid = ".((int) $this->id);

		dol_syslog(get_class($this)."::expire()", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			dol_print_error($this->db);
			$this->error = $this->db->lasterror();
			$error++;
		}

		if (!$error && !$notrigger) {
			// Call trigger
			$result = $this->call_trigger('VISITEMEDICAL_EXPIRE', $user);
			if ($result < 0) {
				$error++;
			}
			// End call triggers
		}
		
		// Set new ref and current status
		if (!$error) {
			$this->status = self::STATUS_EXPIRE;
		}

		if (!$error) {
			$naturesVisite = explode(",", $this->naturevisite);
			$elementPrerequis = new ElementPrerequis($this->db);

			// Formations
			$userFormation = new UserFormation($this->db);
			$formation = new Formation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userFormationToSuspend = $userFormation->getObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userFormationToSuspend as $user_formation) {
					$formation->fetch($user_formation->fk_formation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $formation, 0, 0);
					if($asPrerequis < 0) {
						$resultsuspen = $user_formation->suspend($user);

						if($resultsuspen < 0) {
							$error++;
						}
					}
				}
			}
			
			// Habilitations
			$userHabilitation = new UserHabilitation($this->db);
			$habilitation = new Habilitation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userHabilitationToSuspend = $userHabilitation->getObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userHabilitationToSuspend as $user_habilitation) {
					$habilitation->fetch($user_habilitation->fk_habilitation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $habilitation, 0, 0);
					if($asPrerequis < 0) {
						$resultsuspen = $user_habilitation->suspend($user);

						if($resultsuspen < 0) {
							$error++;
						}
					}
				}
			}

			// Autorisations
			$userAutorisation = new UserAutorisation($this->db);
			$autorisation = new Autorisation($this->db);
			foreach($naturesVisite as $id_naturevisite) {
				$userAutorisationToSuspend = $userAutorisation->getObjectNeedPrerequis($this->fk_user, $id_naturevisite, 'nature_visite');
				foreach($userAutorisationToSuspend as $user_autorisation) {
					$autorisation->fetch($user_autorisation->fk_autorisation);
					$asPrerequis = $elementPrerequis->gestionPrerequis($this->fk_user, $autorisation, 0, 0);
					if($asPrerequis < 0) {
						$resultsuspen = $user_autorisation->suspend($user);

						if($resultsuspen < 0) {
							$error++;
						}
					}
				}
			}
		}

		if (!$error) {
			$this->db->commit();
			return 1;
		} else {
			$this->db->rollback();
			return -1;
		}
	}

	/**
	 *	Set close status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						Return integer <0 if KO, 0=Nothing done, >0 if OK
	 */
	public function close($user, $notrigger = 0)
	{
		// Protection
		if ($this->status == self::STATUS_CLOSE) {
			return 0;
		}

		/* if (! ((!getDolGlobalInt('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('formationhabilitation','write'))
		 || (getDolGlobalInt('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('formationhabilitation','formationhabilitation_advance','validate'))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_CLOSE, $notrigger, 'VISITEMEDICAL_CLOSE');
	}

	/**
	 * getTooltipContentArray
	 *
	 * @param 	array 	$params 	Params to construct tooltip data
	 * @since 	v18
	 * @return 	array
	 */
	public function getTooltipContentArray($params)
	{
		global $langs;

		$datas = [];

		if (getDolGlobalInt('MAIN_OPTIMIZEFORTEXTBROWSER')) {
			return ['optimize' => $langs->trans("ShowVisiteMedical")];
		}
		$datas['picto'] = img_picto('', $this->picto).' <u>'.$langs->trans("VisiteMedical").'</u>';
		if (isset($this->status)) {
			$datas['picto'] .= ' '.$this->getLibStatut(5);
		}
		if (property_exists($this, 'ref')) {
			$datas['ref'] = '<br><b>'.$langs->trans('Ref').':</b> '.$this->ref;
		}
		if (property_exists($this, 'label')) {
			$datas['ref'] = '<br>'.$langs->trans('Label').':</b> '.$this->label;
		}

		return $datas;
	}

	/**
	 *  Return a link to the object card (with optionaly the picto)
	 *
	 *  @param  int     $withpicto                  Include picto in link (0=No picto, 1=Include picto into link, 2=Only picto)
	 *  @param  string  $option                     On what the link point to ('nolink', ...)
	 *  @param  int     $notooltip                  1=Disable tooltip
	 *  @param  string  $morecss                    Add more css on link
	 *  @param  int     $save_lastsearch_value      -1=Auto, 0=No save of lastsearch_values when clicking, 1=Save lastsearch_values whenclicking
	 *  @return	string                              String with URL
	 */
	public function getNomUrl($withpicto = 0, $option = '', $notooltip = 0, $morecss = '', $save_lastsearch_value = -1)
	{
		global $conf, $langs, $hookmanager;

		if (!empty($conf->dol_no_mouse_hover)) {
			$notooltip = 1; // Force disable tooltips
		}

		$result = '';
		$params = [
			'id' => $this->id,
			'objecttype' => $this->element.($this->module ? '@'.$this->module : ''),
			'option' => $option,
		];
		$classfortooltip = 'classfortooltip';
		$dataparams = '';
		if (getDolGlobalInt('MAIN_ENABLE_AJAX_TOOLTIP')) {
			$classfortooltip = 'classforajaxtooltip';
			$dataparams = ' data-params="'.dol_escape_htmltag(json_encode($params)).'"';
			$label = '';
		} else {
			$label = implode($this->getTooltipContentArray($params));
		}

		$url = dol_buildpath('/formationhabilitation/visitemedical_card.php', 1).'?id='.$this->id;

		if ($option !== 'nolink') {
			// Add param to save lastsearch_values or not
			$add_save_lastsearch_values = ($save_lastsearch_value == 1 ? 1 : 0);
			if ($save_lastsearch_value == -1 && isset($_SERVER["PHP_SELF"]) && preg_match('/list\.php/', $_SERVER["PHP_SELF"])) {
				$add_save_lastsearch_values = 1;
			}
			if ($url && $add_save_lastsearch_values) {
				$url .= '&save_lastsearch_values=1';
			}
		}

		$linkclose = '';
		if (empty($notooltip)) {
			if (getDolGlobalInt('MAIN_OPTIMIZEFORTEXTBROWSER')) {
				$label = $langs->trans("ShowVisiteMedical");
				$linkclose .= ' alt="'.dol_escape_htmltag($label, 1).'"';
			}
			$linkclose .= ($label ? ' title="'.dol_escape_htmltag($label, 1).'"' : ' title="tocomplete"');
			$linkclose .= $dataparams.' class="'.$classfortooltip.($morecss ? ' '.$morecss : '').'"';
		} else {
			$linkclose = ($morecss ? ' class="'.$morecss.'"' : '');
		}

		if ($option == 'nolink' || empty($url)) {
			$linkstart = '<span';
		} else {
			$linkstart = '<a href="'.$url.'"';
		}
		$linkstart .= $linkclose.'>';
		if ($option == 'nolink' || empty($url)) {
			$linkend = '</span>';
		} else {
			$linkend = '</a>';
		}

		$result .= $linkstart;

		if (empty($this->showphoto_on_popup)) {
			if ($withpicto) {
				$result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), (($withpicto != 2) ? 'class="paddingright"' : ''), 0, 0, $notooltip ? 0 : 1);
			}
		} else {
			if ($withpicto) {
				require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

				list($class, $module) = explode('@', $this->picto);
				$upload_dir = $conf->$module->multidir_output[$conf->entity]."/$class/".dol_sanitizeFileName($this->ref);
				$filearray = dol_dir_list($upload_dir, "files");
				$filename = $filearray[0]['name'];
				if (!empty($filename)) {
					$pospoint = strpos($filearray[0]['name'], '.');

					$pathtophoto = $class.'/'.$this->ref.'/thumbs/'.substr($filename, 0, $pospoint).'_mini'.substr($filename, $pospoint);
					if (!getDolGlobalString(strtoupper($module.'_'.$class).'_FORMATLISTPHOTOSASUSERS')) {
						$result .= '<div class="floatleft inline-block valignmiddle divphotoref"><div class="photoref"><img class="photo'.$module.'" alt="No photo" border="0" src="'.DOL_URL_ROOT.'/viewimage.php?modulepart='.$module.'&entity='.$conf->entity.'&file='.urlencode($pathtophoto).'"></div></div>';
					} else {
						$result .= '<div class="floatleft inline-block valignmiddle divphotoref"><img class="photouserphoto userphoto" alt="No photo" border="0" src="'.DOL_URL_ROOT.'/viewimage.php?modulepart='.$module.'&entity='.$conf->entity.'&file='.urlencode($pathtophoto).'"></div>';
					}

					$result .= '</div>';
				} else {
					$result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="'.(($withpicto != 2) ? 'paddingright ' : '').'"'), 0, 0, $notooltip ? 0 : 1);
				}
			}
		}

		if ($withpicto != 2) {
			$result .= $this->ref;
		}

		$result .= $linkend;
		//if ($withpicto != 2) $result.=(($addlabel && $this->label) ? $sep . dol_trunc($this->label, ($addlabel > 1 ? $addlabel : 0)) : '');

		global $action, $hookmanager;
		$hookmanager->initHooks(array($this->element.'dao'));
		$parameters = array('id' => $this->id, 'getnomurl' => &$result);
		$reshook = $hookmanager->executeHooks('getNomUrl', $parameters, $this, $action); // Note that $action and $object may have been modified by some hooks
		if ($reshook > 0) {
			$result = $hookmanager->resPrint;
		} else {
			$result .= $hookmanager->resPrint;
		}

		return $result;
	}

	/**
	 *	Return a thumb for kanban views
	 *
	 *	@param      string	    $option                 Where point the link (0=> main card, 1,2 => shipment, 'nolink'=>No link)
	 *  @param		array		$arraydata				Array of data
	 *  @return		string								HTML Code for Kanban thumb.
	 */
	public function getKanbanView($option = '', $arraydata = null)
	{
		global $conf, $langs;

		$selected = (empty($arraydata['selected']) ? 0 : $arraydata['selected']);

		$return = '<div class="box-flex-item box-flex-grow-zero">';
		$return .= '<div class="info-box info-box-sm">';
		$return .= '<span class="info-box-icon bg-infobox-action">';
		$return .= img_picto('', $this->picto);
		$return .= '</span>';
		$return .= '<div class="info-box-content">';
		$return .= '<span class="info-box-ref inline-block tdoverflowmax150 valignmiddle">'.(method_exists($this, 'getNomUrl') ? $this->getNomUrl() : $this->ref).'</span>';
		if ($selected >= 0) {
			$return .= '<input id="cb'.$this->id.'" class="flat checkforselect fright" type="checkbox" name="toselect[]" value="'.$this->id.'"'.($selected ? ' checked="checked"' : '').'>';
		}
		if (property_exists($this, 'label')) {
			$return .= ' <div class="inline-block opacitymedium valignmiddle tdoverflowmax100">'.$this->label.'</div>';
		}
		if (property_exists($this, 'thirdparty') && is_object($this->thirdparty)) {
			$return .= '<br><div class="info-box-ref tdoverflowmax150">'.$this->thirdparty->getNomUrl(1).'</div>';
		}
		if (property_exists($this, 'amount')) {
			$return .= '<br>';
			$return .= '<span class="info-box-label amount">'.price($this->amount, 0, $langs, 1, -1, -1, $conf->currency).'</span>';
		}
		if (method_exists($this, 'getLibStatut')) {
			$return .= '<br><div class="info-box-status">'.$this->getLibStatut(3).'</div>';
		}
		$return .= '</div>';
		$return .= '</div>';
		$return .= '</div>';

		return $return;
	}

	/**
	 *  Return the label of the status
	 *
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return	string 			       Label of status
	 */
	public function getLabelStatus($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

	/**
	 *  Return the label of the status
	 *
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return	string 			       Label of status
	 */
	public function getLibStatut($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	/**
	 *  Return the label of a given status
	 *
	 *  @param	int		$status        Id status
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return string 			       Label of status
	 */
	public function LibStatut($status, $mode = 0)
	{
		// phpcs:enable
		if (is_null($status)) {
			return '';
		}

		if (empty($this->labelStatus) || empty($this->labelStatusShort)) {
			global $langs;
			//$langs->load("formationhabilitation@formationhabilitation");
			$this->labelStatus[self::STATUS_APTE] = $langs->transnoentitiesnoconv('Apte');
			$this->labelStatus[self::STATUS_INAPTE] = $langs->transnoentitiesnoconv('Inapte');
			$this->labelStatus[self::STATUS_CONDITIONNEL] = $langs->transnoentitiesnoconv('Conditionnel');
			$this->labelStatus[self::STATUS_CLOSE] = $langs->transnoentitiesnoconv('Clôturée');
			$this->labelStatus[self::STATUS_EXPIRE] = $langs->transnoentitiesnoconv('Expirée');
			$this->labelStatusShort[self::STATUS_APTE] = $langs->transnoentitiesnoconv('Apte');
			$this->labelStatusShort[self::STATUS_INAPTE] = $langs->transnoentitiesnoconv('Inapte');
			$this->labelStatusShort[self::STATUS_CONDITIONNEL] = $langs->transnoentitiesnoconv('Conditionnel');
			$this->labelStatusShort[self::STATUS_CLOSE] = $langs->transnoentitiesnoconv('Clôturée');
			$this->labelStatusShort[self::STATUS_EXPIRE] = $langs->transnoentitiesnoconv('Expirée');
		}

		$statusType = 'status'.$status;
		if ($status == self::STATUS_APTE) {
			$statusType = 'status4';
		}
		elseif ($status == self::STATUS_INAPTE) {
			$statusType = 'status8';
		}
		elseif ($status == self::STATUS_CONDITIONNEL) {
			$statusType = 'status1';
		}
		elseif ($status == self::STATUS_CLOSE) {
			$statusType = 'status9';
		}
		elseif ($status == self::STATUS_EXPIRE) {
			$statusType = 'status10';
		}

		return dolGetStatus($this->labelStatus[$status], $this->labelStatusShort[$status], '', $statusType, $mode);
	}

	/**
	 *	Load the info information in the object
	 *
	 *	@param  int		$id       Id of object
	 *	@return	void
	 */
	public function info($id)
	{
		$sql = "SELECT rowid,";
		$sql .= " date_creation as datec, tms as datem";
		if (!empty($this->fields['date_validation'])) {
			$sql .= ", date_validation as datev";
		}
		if (!empty($this->fields['fk_user_creat'])) {
			$sql .= ", fk_user_creat";
		}
		if (!empty($this->fields['fk_user_modif'])) {
			$sql .= ", fk_user_modif";
		}
		if (!empty($this->fields['fk_user_valid'])) {
			$sql .= ", fk_user_valid";
		}
		$sql .= " FROM ".MAIN_DB_PREFIX.$this->table_element." as t";
		$sql .= " WHERE t.rowid = ".((int) $id);

		$result = $this->db->query($sql);
		if ($result) {
			if ($this->db->num_rows($result)) {
				$obj = $this->db->fetch_object($result);

				$this->id = $obj->rowid;

				if (!empty($this->fields['fk_user_creat'])) {
					$this->user_creation_id = $obj->fk_user_creat;
				}
				if (!empty($this->fields['fk_user_modif'])) {
					$this->user_modification_id = $obj->fk_user_modif;
				}
				if (!empty($this->fields['fk_user_valid'])) {
					$this->user_validation_id = $obj->fk_user_valid;
				}
				$this->date_creation     = $this->db->jdate($obj->datec);
				$this->date_modification = empty($obj->datem) ? '' : $this->db->jdate($obj->datem);
				if (!empty($obj->datev)) {
					$this->date_validation   = empty($obj->datev) ? '' : $this->db->jdate($obj->datev);
				}
			}

			$this->db->free($result);
		} else {
			dol_print_error($this->db);
		}
	}

	/**
	 * Initialise object with example values
	 * Id must be 0 if object instance is a specimen
	 *
	 * @return void
	 */
	public function initAsSpecimen()
	{
		// Set here init that are not commonf fields
		// $this->property1 = ...
		// $this->property2 = ...

		$this->initAsSpecimenCommon();
	}

	/**
	 * 	Create an array of lines
	 *
	 * 	@return array|int		array of lines if OK, <0 if KO
	 */
	public function getLinesArray()
	{
		$this->lines = array();

		$objectline = new VisiteMedicalLine($this->db);
		$result = $objectline->fetchAll('ASC', 'position', 0, 0, array('customsql'=>'fk_visitemedical = '.((int) $this->id)));

		if (is_numeric($result)) {
			$this->setErrorsFromObject($objectline);
			return $result;
		} else {
			$this->lines = $result;
			return $this->lines;
		}
	}

	/**
	 *  Returns the reference to the following non used object depending on the active numbering module.
	 *
	 *  @return string      		Object free reference
	 */
	public function getNextNumRef()
	{
		global $langs, $conf;
		$langs->load("formationhabilitation@formationhabilitation");

		if (!getDolGlobalString('FORMATIONHABILITATION_MYOBJECT_ADDON')) {
			$conf->global->FORMATIONHABILITATION_MYOBJECT_ADDON = 'mod_visitemedical_standard';
		}

		if (getDolGlobalString('FORMATIONHABILITATION_MYOBJECT_ADDON')) {
			$mybool = false;

			$file = getDolGlobalString('FORMATIONHABILITATION_MYOBJECT_ADDON').".php";
			$classname = getDolGlobalString('FORMATIONHABILITATION_MYOBJECT_ADDON');

			// Include file with class
			$dirmodels = array_merge(array('/'), (array) $conf->modules_parts['models']);
			foreach ($dirmodels as $reldir) {
				$dir = dol_buildpath($reldir."core/modules/formationhabilitation/");

				// Load file with numbering class (if found)
				$mybool |= @include_once $dir.$file;
			}

			if ($mybool === false) {
				dol_print_error('', "Failed to include file ".$file);
				return '';
			}

			if (class_exists($classname)) {
				$obj = new $classname();
				$numref = $obj->getNextValue($this);

				if ($numref != '' && $numref != '-1') {
					return $numref;
				} else {
					$this->error = $obj->error;
					//dol_print_error($this->db,get_class($this)."::getNextNumRef ".$obj->error);
					return "";
				}
			} else {
				print $langs->trans("Error")." ".$langs->trans("ClassNotFound").' '.$classname;
				return "";
			}
		} else {
			print $langs->trans("ErrorNumberingModuleNotSetup", $this->element);
			return "";
		}
	}

	/**
	 *  Create a document onto disk according to template module.
	 *
	 *  @param	    string		$modele			Force template to use ('' to not force)
	 *  @param		Translate	$outputlangs	objet lang a utiliser pour traduction
	 *  @param      int			$hidedetails    Hide details of lines
	 *  @param      int			$hidedesc       Hide description
	 *  @param      int			$hideref        Hide ref
	 *  @param      null|array  $moreparams     Array to provide more information
	 *  @return     int         				0 if KO, 1 if OK
	 */
	// public function generateDocument($modele, $outputlangs, $hidedetails = 0, $hidedesc = 0, $hideref = 0, $moreparams = null)
	// {
	// 	global $conf, $langs;

	// 	$result = 0;
	// 	$includedocgeneration = 1;

	// 	$langs->load("formationhabilitation@formationhabilitation");

	// 	if (!dol_strlen($modele)) {
	// 		$modele = 'standard_visitemedical';

	// 		if (!empty($this->model_pdf)) {
	// 			$modele = $this->model_pdf;
	// 		} elseif (getDolGlobalString('MYOBJECT_ADDON_PDF')) {
	// 			$modele = getDolGlobalString('MYOBJECT_ADDON_PDF');
	// 		}
	// 	}

	// 	$modelpath = "core/modules/formationhabilitation/doc/";

	// 	if ($includedocgeneration && !empty($modele)) {
	// 		$result = $this->commonGenerateDocument($modelpath, $modele, $outputlangs, $hidedetails, $hidedesc, $hideref, $moreparams);
	// 	}

	// 	return $result;
	// }

	/**
	 * Action executed by cron
	 * Changement de statut automatique des visite médicale
	 *
	 * @return	int			0 if OK, <>0 if KO (this function is used also by cron so only 0 is OK)
	 */
	public function MajStatuts()
	{
		global $conf, $langs, $user;

		$visiteMedicale = new self($this->db);
		$error = 0;
		$this->output = '';
		$this->error = '';

		dol_syslog(__METHOD__." start", LOG_INFO);

		$now = dol_now();

		$this->db->begin();

		$sql = "SELECT vm.rowid, vm.ref, vm.fk_user";
		$sql .= " FROM ".MAIN_DB_PREFIX."formationhabilitation_visitemedical as vm";
		$sql .= " WHERE vm.datefinvalidite IS NOT NULL";
		$sql .= " AND vm.datefinvalidite < '".substr($this->db->idate($now), 0, 10)."'";
		$sql .= " AND vm.status != ".self::STATUS_CLOSE;
		$sql .= " AND vm.status != ".self::STATUS_EXPIRE;

		$resql = $this->db->query($sql);
		if($resql) {
			while($obj = $this->db->fetch_object($resql)) {
				$visiteMedicale->fetch($obj->rowid);
				$resultexpire = $visiteMedicale->expire($user);

				if($resultexpire < 0) {
					$error++;
					$this->error .= $visiteMedicale->error;
				}
				else {
					$this->output .= "La visite médicale $obj->ref a été passé au statut 'Expirée'<br>";

					global $dolibarr_main_url_root;

					$user_static = new User($this->db);
					$user_static->fetch($obj->fk_user);
					
					$user_group = new UserGroup($this->db);
					$user_group->fetch(0, 'Administratif');
					$liste_user = $user_group->listUsersForGroup('u.statut=1');

					$subject = "[OPTIM Industries] Notification automatique ".$langs->transnoentitiesnoconv($this->module);
					$from = $conf->global->MAIN_MAIL_EMAIL_FROM;

					$to = '';
					foreach($liste_user as $uservalide){
						if(!empty($uservalide->email)){
							$to .= $uservalide->email.", ";
						}
					}
					// if(!empty($user_static->email)) {
					// 	$to .= $user_static->email.", ";
					// }
					rtrim($to, ', ');
					
					$urlwithouturlroot = preg_replace('/'.preg_quote(DOL_URL_ROOT, '/').'$/i', '', trim($dolibarr_main_url_root));
					$urlwithroot = $urlwithouturlroot.DOL_URL_ROOT; // This is to use external domain name found into config file
					$link = '<a href="'.$urlwithroot.'/custom/formationhabilitation/visitemedical_card.php?id='.$obj->rowid.'">'.$obj->ref.'</a>';
					$message = $langs->transnoentitiesnoconv("EMailTextVMExpire", $link);

					$mail = new CMailFile(
						$subject,
						$to,
						$from,
						$message,
						array(),
						array(),
						array(),
						'',
						'',
						0,
						1,
						'',
						''
					);

					if(!empty($to)) {
						$resultmail = $mail->sendfile();
					}
				}
			}
		}

		if(!$error) {
			$this->db->commit();
		}
		else {
			$this->db->rollback();
		}

		dol_syslog(__METHOD__." end", LOG_INFO);

		return $error;
	}

	/**
	 * 	Est-ce que l'utilisateur $userid possède une aptitude médicale avec la nature $natureid 
	 *
	 * 	@param  int		$userid       	Id of User
	 *  @param  int		$natureid    	Id of Nature
	 * 	@return	bool						
	 */
	// public function userAsAptitudeMedicale($userid, $natureid)
	// {
	// 	global $conf, $user;
	// 	$res = array();

	// 	if(empty($userid) || empty($natureid)) {
	// 		$this->error = 'Il faut renseigner les aptitudes médicales nécessaires pour le collaborateur';
	// 		return -1;
	// 	}

	// 	$sql = "SELECT vm.rowid";
	// 	$sql .= " FROM ".MAIN_DB_PREFIX."formationhabilitation_visitemedical as vm";
	// 	$sql .= " WHERE vm.fk_user = $userid";
	// 	$sql .= " AND vm.naturevisite = $natureid";
	// 	$sql .= " AND vm.status = ".self::STATUS_APTE;
	// 	$sql .= " AND vm.datevisite <= '".substr($this->db->idate(dol_now()), 0, 10)."'";
	// 	$sql .= " AND vm.datefinvalidite >= '".substr($this->db->idate(dol_now()), 0, 10)."'";

	// 	dol_syslog(get_class($this)."::userAsAptitudeMedicale", LOG_DEBUG);
	// 	$resql = $this->db->query($sql);

	// 	if ($resql) {
	// 		if($this->db->num_rows($resql)) {
	// 			$this->db->free($resql);
	// 			return 1;
	// 		}
	// 		else {
	// 			$this->db->free($resql);
	// 			return 0;
	// 		}
	// 	} else {
	// 		$this->error = $this->db->lasterror();
	// 		return -1;
	// 	}
	// }

	/**
	 * 	Return les informations d'une nature de visite
	 *
	 * 	@param  int		$natureid       Id of Nature
	 * 	@return	array						
	 */
	public function getNatureInfo($natureid)
	{
		global $conf, $user;
		$res = array();

		$sql = "SELECT v.label";
		$sql .= " FROM ".MAIN_DB_PREFIX."c_nature_visite as v";
		$sql .= " WHERE v.rowid = $natureid";

		dol_syslog(get_class($this)."::getNatureInfo", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			$obj = $this->db->fetch_object($resql);
			$res['label'] = $obj->label;

			$this->db->free($resql);
			return $res;
		} else {
			$this->error = $this->db->lasterror();
			return -1;
		}
	}

	/**
	 * 	Return toutes les natures de VM à partir du dictionnaire
	 *
	 * 	@return	array						
	 */
	public function getAllNature()
	{
		global $conf, $user;
		$res = array();

		$sql = "SELECT v.rowid, v.label";
		$sql .= " FROM ".MAIN_DB_PREFIX."c_nature_visite as v";
		$sql .= " WHERE v.active = 1";

		dol_syslog(get_class($this)."::getAllNature", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			while($obj = $this->db->fetch_object($resql)) {
				$res[$obj->rowid] = $obj->label;
			}

			$this->db->free($resql);
			return $res;
		} else {
			$this->error = $this->db->lasterror();
			return -1;
		}
	}

	/**
	 * 	Liste des nature visite possédait par l'utilisateur
	 *
	 * 	@param  int		$userid       	Id of User
	 * 	@return	array(int)|int			Array with Nature visite		
	 */
	function getAllNatureVisiteForUser($userid) {
		$res = array();

		$sql = "SELECT DISTINCT vm.naturevisite";
		$sql .= " FROM ".MAIN_DB_PREFIX."formationhabilitation_visitemedical as vm";
		$sql .= " WHERE vm.fk_user = $userid";
		$sql .= " AND (vm.status = ".self::STATUS_APTE." OR vm.status = ".self::STATUS_CONDITIONNEL.")";

		dol_syslog(get_class($this)."::getAllNatureVisiteForUser", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			while ($obj = $this->db->fetch_object($resql)) {
				foreach(explode(",", $obj->naturevisite) as $naturevisite) {
					$res[] = $naturevisite;
				}
			}

			$this->db->free($resql);
			return $res;
		}
		else {
			$this->error = $this->db->lasterror();
			return -1;
		}
	}

	/**
	 * 	Liste des visites médicales à cloturée lors de la création d'une nouvelle
	 *
	 * 	@return	array			Array of VisiteMedical object
	 */
	function getVisiteMedicaleToClose() {
		$res = array();
	
		$visiteMedicale = new VisiteMedical($this->db);
		$naturesvisite = array_map('trim', explode(',', $this->naturevisite));
		$conditions = [];
		foreach ($naturesvisite as $naturevisite) {
			$conditions[] = "FIND_IN_SET('$naturevisite', vm.naturevisite) > 0";
		}

		$sql = "SELECT DISTINCT vm.rowid";
		$sql .= " FROM ".MAIN_DB_PREFIX."formationhabilitation_visitemedical as vm";
		$sql .= " WHERE vm.fk_user = $this->fk_user";
		$sql .= " AND vm.rowid != $this->id";
		$sql .= " AND (".implode(' OR ', $conditions).")";
		$sql .= " AND (vm.status = ".self::STATUS_APTE." OR vm.status = ".self::STATUS_CONDITIONNEL." OR vm.status = ".self::STATUS_INAPTE." OR vm.status = ".self::STATUS_EXPIRE.")";

		dol_syslog(get_class($this)."::getVisiteMedicaleToClose", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			while ($obj = $this->db->fetch_object($resql)) {
				$visiteMedicale->fetch($obj->rowid);
				$nature_values = array_map('trim', explode(',', $visiteMedicale->naturevisite));
				
				// Vérifier que chaque élément est dans les valeurs autorisées
				if (array_diff($nature_values, $naturesvisite) === []) {
					$res[] = clone $visiteMedicale;
				}
			}

			$this->db->free($resql);
			return $res;
		}
		else {
			$this->error = $this->db->lasterror();
			return -1;
		}
	}
}


require_once DOL_DOCUMENT_ROOT.'/core/class/commonobjectline.class.php';

/**
 * Class VisiteMedicalLine. You can also remove this and generate a CRUD class for lines objects.
 */
class VisiteMedicalLine extends CommonObjectLine
{
	// To complete with content of an object VisiteMedicalLine
	// We should have a field rowid, fk_visitemedical and position

	/**
	 * @var int  Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 0;

	/**
	 * Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
		$this->db = $db;
	}
}
